jQuery.noConflict();
var $j = jQuery.noConflict();